package com.nanda.aplikasiquran.model.main

class DaftarKota {
    var id: Int? = null
    var nama: String? = null

    override fun toString(): String {
        return nama.toString()
    }
}